import streamlit as st
import pandas as pd
import joblib

# Load the trained model
model = joblib.load("best_model.pkl")

st.set_page_config(page_title="Employee Salary Classification", page_icon="💼", layout="centered")

st.title("💼 Employee Salary Classification App")
st.markdown("Predict whether an employee earns >50K or ≤50K based on input features.")

# Sidebar inputs (these must match your training feature columns)
st.sidebar.header("Input Employee Details")

# Input fields matching the actual training features
age = st.sidebar.slider("Age", 18, 90, 30)
workclass = st.sidebar.selectbox("Work Class", [
    "Private", "Self-emp-not-inc", "Self-emp-inc", "Federal-gov", 
    "Local-gov", "State-gov", "Without-pay", "Never-worked"
])
fnlwgt = st.sidebar.number_input("Final Weight", min_value=10000, max_value=1500000, value=200000)
educational_num = st.sidebar.slider("Education Number", 1, 16, 10)
marital_status = st.sidebar.selectbox("Marital Status", [
    "Married-civ-spouse", "Divorced", "Never-married", "Separated", 
    "Widowed", "Married-spouse-absent", "Married-AF-spouse"
])
occupation = st.sidebar.selectbox("Occupation", [
    "Tech-support", "Craft-repair", "Other-service", "Sales",
    "Exec-managerial", "Prof-specialty", "Handlers-cleaners", "Machine-op-inspct",
    "Adm-clerical", "Farming-fishing", "Transport-moving", "Priv-house-serv",
    "Protective-serv", "Armed-Forces"
])
relationship = st.sidebar.selectbox("Relationship", [
    "Wife", "Own-child", "Husband", "Not-in-family", "Other-relative", "Unmarried"
])
race = st.sidebar.selectbox("Race", [
    "White", "Asian-Pac-Islander", "Amer-Indian-Eskimo", "Other", "Black"
])
gender = st.sidebar.selectbox("Gender", ["Male", "Female"])
capital_gain = st.sidebar.number_input("Capital Gain", min_value=0, max_value=100000, value=0)
capital_loss = st.sidebar.number_input("Capital Loss", min_value=0, max_value=5000, value=0)
hours_per_week = st.sidebar.slider("Hours per week", 1, 100, 40)
native_country = st.sidebar.selectbox("Native Country", [
    "United-States", "Cambodia", "England", "Puerto-Rico", "Canada", "Germany",
    "Outlying-US(Guam-USVI-etc)", "India", "Japan", "Greece", "South", "China",
    "Cuba", "Iran", "Honduras", "Philippines", "Italy", "Poland", "Jamaica",
    "Vietnam", "Mexico", "Portugal", "Ireland", "France", "Dominican-Republic",
    "Laos", "Ecuador", "Taiwan", "Haiti", "Columbia", "Hungary", "Guatemala",
    "Nicaragua", "Scotland", "Thailand", "Yugoslavia", "El-Salvador",
    "Trinadad&Tobago", "Peru", "Hong", "Holand-Netherlands"
])

# Note: We need to encode these categorical values to match the training data
# For simplicity, we'll use label encoding similar to the training process
from sklearn.preprocessing import LabelEncoder

# Create encoders and encode the categorical variables
workclass_encoder = LabelEncoder()
marital_encoder = LabelEncoder()
occupation_encoder = LabelEncoder()
relationship_encoder = LabelEncoder()
race_encoder = LabelEncoder()
gender_encoder = LabelEncoder()
country_encoder = LabelEncoder()

# For demo purposes, we'll use simple mappings based on common values
# In production, you should save and load the actual encoders used during training
workclass_mapping = {"Private": 3, "Self-emp-not-inc": 5, "Self-emp-inc": 4, "Federal-gov": 0, 
                    "Local-gov": 1, "State-gov": 6, "Without-pay": 7, "Never-worked": 2}
marital_mapping = {"Married-civ-spouse": 2, "Divorced": 0, "Never-married": 4, "Separated": 5, 
                  "Widowed": 6, "Married-spouse-absent": 3, "Married-AF-spouse": 1}
occupation_mapping = {"Tech-support": 13, "Craft-repair": 2, "Other-service": 8, "Sales": 12,
                     "Exec-managerial": 3, "Prof-specialty": 10, "Handlers-cleaners": 5, 
                     "Machine-op-inspct": 6, "Adm-clerical": 0, "Farming-fishing": 4, 
                     "Transport-moving": 14, "Priv-house-serv": 9, "Protective-serv": 11, 
                     "Armed-Forces": 1}
relationship_mapping = {"Wife": 1, "Own-child": 3, "Husband": 0, "Not-in-family": 4, 
                       "Other-relative": 5, "Unmarried": 2}
race_mapping = {"White": 4, "Asian-Pac-Islander": 1, "Amer-Indian-Eskimo": 0, "Other": 3, "Black": 2}
gender_mapping = {"Male": 1, "Female": 0}
country_mapping = {"United-States": 39, "Cambodia": 4, "England": 9, "Puerto-Rico": 30, "Canada": 5}

# Build input DataFrame with encoded values
input_df = pd.DataFrame({
    'age': [age],
    'workclass': [workclass_mapping.get(workclass, 3)],  # Default to Private
    'fnlwgt': [fnlwgt],
    'educational-num': [educational_num],
    'marital-status': [marital_mapping.get(marital_status, 2)],  # Default to Married-civ-spouse
    'occupation': [occupation_mapping.get(occupation, 8)],  # Default to Other-service
    'relationship': [relationship_mapping.get(relationship, 0)],  # Default to Husband
    'race': [race_mapping.get(race, 4)],  # Default to White
    'gender': [gender_mapping.get(gender, 1)],  # Default to Male
    'capital-gain': [capital_gain],
    'capital-loss': [capital_loss],
    'hours-per-week': [hours_per_week],
    'native-country': [country_mapping.get(native_country, 39)]  # Default to United-States
})

st.write("### 🔎 Input Data")
st.write(input_df)

# Predict button
if st.button("Predict Salary Class"):
    prediction = model.predict(input_df)
    st.success(f"✅ Prediction: {prediction[0]}")

# Batch prediction
st.markdown("---")
st.markdown("#### 📂 Batch Prediction")
st.markdown("**Note:** Upload a CSV file with the following columns in order:")
st.markdown("age, workclass, fnlwgt, educational-num, marital-status, occupation, relationship, race, gender, capital-gain, capital-loss, hours-per-week, native-country")
uploaded_file = st.file_uploader("Upload a CSV file for batch prediction", type="csv")

if uploaded_file is not None:
    batch_data = pd.read_csv(uploaded_file)
    st.write("Uploaded data preview:", batch_data.head())
    
    # Check if the uploaded data has the correct columns
    expected_columns = ['age', 'workclass', 'fnlwgt', 'educational-num', 'marital-status', 
                       'occupation', 'relationship', 'race', 'gender', 'capital-gain', 
                       'capital-loss', 'hours-per-week', 'native-country']
    
    if list(batch_data.columns) == expected_columns:
        try:
            batch_preds = model.predict(batch_data)
            batch_data['PredictedClass'] = batch_preds
            st.write("✅ Predictions:")
            st.write(batch_data.head())
            csv = batch_data.to_csv(index=False).encode('utf-8')
            st.download_button("Download Predictions CSV", csv, file_name='predicted_classes.csv', mime='text/csv')
        except Exception as e:
            st.error(f"Error making predictions: {str(e)}")
            st.info("Make sure your data is properly encoded (categorical values should be numeric)")
    else:
        st.error("❌ Column mismatch! Please ensure your CSV has the exact columns listed above.")
        st.write("Your columns:", list(batch_data.columns))
        st.write("Expected columns:", expected_columns)

